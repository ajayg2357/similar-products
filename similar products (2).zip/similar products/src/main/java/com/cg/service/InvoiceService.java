package com.cg.service;

import java.util.List;

import com.cg.bean.Similar;

public interface InvoiceService {

	List<Similar> viewAllInvoice();

	Similar findSingleInvoice(int id);

	List<Similar> findSingleInvoice1(int brand_id);
	
	Similar createInvoice(Similar obj);
}
