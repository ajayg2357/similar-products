package com.cg.service;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Similar;
import com.cg.dao.InvoiceRepo;

@Service
public class InvoiceServiceImpl implements InvoiceService {
	@Autowired
	InvoiceRepo dao;

	static Scanner sc = new Scanner(System.in);

	@Override
	public Similar createInvoice(Similar obj) {
		obj.setId((int) (Math.random() * 1000 + 1));

		int d = (obj.getDiscount() * obj.getPrice()) / 100;
		int discount = (obj.getDiscount() * obj.getPrice()) / 100;
		obj.setDiscount(discount);
		int amt = obj.getPrice() - obj.getDiscount();
		int conprice = obj.getPrice() - d;
		obj.setConprice(conprice);
		int tax = (obj.getConprice() * obj.getTax()) / 100;
		obj.setTax(tax);
		int promo = (obj.getConprice() * obj.getPromo()) / 100;
		obj.setPromo(promo);
		int final1 = obj.getConprice() + obj.getTax() + obj.getCharges() - obj.getPromo();
		obj.setFinalprice(final1);

		return obj;
	}

	@Override
	public Similar findSingleInvoice(int id) {

		return dao.findById(id).get();
	}

	@Override
	public List<Similar> findSingleInvoice1(int brand_id) {

		return dao.findbyBrand_id(brand_id);

	}

	@Override
	public List<Similar> viewAllInvoice() {
		return dao.findAll();

	}

}
