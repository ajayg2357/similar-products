package com.cg.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class InvoiceExceptionHandler {
	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity<String>("Exception"+ex.getMessage(), HttpStatus.CONFLICT);
		
	}

	
}
