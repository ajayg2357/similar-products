package com.cg.exception;

public class InvoiceException extends Exception{


	private static final long serialVersionUID = 1L;

	public InvoiceException() {
		super();
		
	}

	public InvoiceException(String msg) {
		super(msg);
		
	}

}
